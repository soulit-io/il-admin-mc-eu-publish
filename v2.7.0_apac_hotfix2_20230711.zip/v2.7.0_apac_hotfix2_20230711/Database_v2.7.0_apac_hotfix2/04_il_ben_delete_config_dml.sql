USE InsuranceLettersVisaBenefits 
SELECT @@servername 'Servidor', db_name(dbid) 'Base de Datos' from master..sysprocesses where spid = @@spid
GO

SELECT getdate() as 'Fecha hora Inicial'
GO

BEGIN TRAN

DELETE FROM [dbo].[service_call_product] 
DELETE FROM [dbo].[service_call_benefit] 
DELETE FROM [dbo].[service_call] 


COMMIT TRAN

SELECT getdate() as 'Fecha hora Final'
GO